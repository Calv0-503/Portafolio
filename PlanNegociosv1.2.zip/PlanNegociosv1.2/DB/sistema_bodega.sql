-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-03-2025 a las 03:39:46
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_bodega`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre_categoria` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre_categoria`) VALUES
(1, 'Electricidad'),
(2, 'Carpintería'),
(3, 'Jardinería'),
(4, 'Plomería'),
(5, 'Pintura'),
(6, 'Construcción'),
(7, 'Automotriz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramientas`
--

CREATE TABLE `herramientas` (
  `id_herramienta` int(11) NOT NULL,
  `codigo_herramienta` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramientas`
--

INSERT INTO `herramientas` (`id_herramienta`, `codigo_herramienta`, `nombre`, `descripcion`, `id_categoria`, `cantidad`) VALUES
(1, 'ELEC001', 'Taladro Eléctrico', 'Taladro de alta potencia', 1, 20),
(2, 'CARP001', 'Sierra Circular', 'Sierra para cortar madera', 2, 78),
(4, 'FR0105', 'Cinta Metrica', 'Cinta de 5mts', 2, 11),
(5, 'ELEC002', 'Taladro Inalámbrico', 'Taladro inalámbrico de 18V', 1, 31),
(6, 'ELEC003', 'Llave de Impacto', 'Llave de impacto neumática', 1, 6),
(7, 'ELEC004', 'Sierra de Inglete', 'Sierra de inglete de 1800W', 1, 11),
(8, 'ELEC005', 'Cortadora de Metal', 'Cortadora de metal de 2000W', 1, 22),
(9, 'ELEC006', 'Amoladora Angular', 'Amoladora angular de 750W', 1, 12),
(10, 'ELEC007', 'Cepillo Eléctrico', 'Cepillo eléctrico de 600W', 1, 4),
(11, 'ELEC008', 'Pistola de Clavos', 'Pistola de clavos neumática', 1, 10),
(12, 'ELEC009', 'Cortadora de Césped', 'Cortadora de césped eléctrica', 1, 20),
(13, 'ELEC010', 'Desbrozadora', 'Desbrozadora de gasolina', 1, 5),
(14, 'ELEC011', 'Pulidora', 'Pulidora de 1200W', 1, 8),
(15, 'ELEC012', 'Soplador de Hojas', 'Soplador de hojas eléctrico', 1, 10),
(16, 'ELEC013', 'Hidrolavadora', 'Hidrolavadora de alta presión', 1, 4),
(17, 'ELEC014', 'Generador Eléctrico', 'Generador eléctrico de 5000W', 1, 3),
(18, 'ELEC015', 'Cortadora de Plasma', 'Cortadora de plasma de 40A', 1, 5),
(19, 'ELEC016', 'Sierra de Banda', 'Sierra de banda de 1000W', 1, 6),
(20, 'ELEC017', 'Torno de Banco', 'Torno de banco para metal', 1, 4),
(21, 'ELEC018', 'Fresadora', 'Fresadora de 1500W', 1, 5),
(22, 'ELEC019', 'Taladro de Columna', 'Taladro de columna de 750W', 1, 7),
(23, 'ELEC020', 'Sierra de Mesa', 'Sierra de mesa de 2000W', 1, 6),
(24, 'ELEC021', 'Lijadora de Banda', 'Lijadora de banda de 800W', 1, 8),
(25, 'CARP002', 'Martillo', 'Martillo de carpintero', 2, 25),
(26, 'CARP003', 'Sierra de Mano', 'Sierra de mano para madera', 2, 25),
(27, 'CARP004', 'Destornillador', 'Destornillador de estrella', 2, 50),
(28, 'CARP005', 'Llave Inglesa', 'Llave inglesa ajustable', 2, 20),
(29, 'CARP006', 'Alicate', 'Alicate de corte', 2, 30),
(30, 'CARP007', 'Cortadora de Azulejos', 'Cortadora manual de azulejos', 2, 4),
(31, 'CARP008', 'Llave Allen', 'Juego de llaves Allen', 2, 35),
(32, 'CARP009', 'Cizalla', 'Cizalla manual', 2, 5),
(33, 'CARP010', 'Cortadora de Vidrio', 'Cortadora de vidrio manual', 2, 10),
(34, 'CARP011', 'Cortadora de Tubos', 'Cortadora de tubos manual', 2, 12),
(35, 'CARP012', 'Llave Stilson', 'Llave Stilson ajustable', 2, 15),
(36, 'CARP013', 'Cortadora de Cables', 'Cortadora de cables manual', 2, 20),
(37, 'CARP014', 'Cortadora de Paredes', 'Cortadora de paredes de 1500W', 2, 5),
(38, 'CARP015', 'Sierra de Cadena', 'Sierra de cadena eléctrica', 2, 7),
(39, 'CARP016', 'Cortadora de Hormigón', 'Cortadora de hormigón de 2000W', 2, 4),
(40, 'CARP017', 'Cortadora de Madera', 'Cortadora de madera de 1500W', 2, 6),
(41, 'CARP018', 'Cortadora de Aluminio', 'Cortadora de aluminio de 1800W', 2, 5),
(42, 'CARP019', 'Cortadora de Acero', 'Cortadora de acero de 2000W', 2, 4),
(43, 'CARP020', 'Cortadora de Plástico', 'Cortadora de plástico de 1200W', 2, 6),
(44, 'JARD001', 'Cortadora de Césped', 'Cortadora de césped a gasolina', 3, 10),
(45, 'JARD002', 'Desbrozadora', 'Desbrozadora eléctrica', 3, 8),
(46, 'JARD003', 'Soplador de Hojas', 'Soplador de hojas a batería', 3, 12),
(47, 'JARD004', 'Podadora de Setos', 'Podadora de setos eléctrica', 3, 7),
(48, 'JARD005', 'Rastrillo', 'Rastrillo de jardín', 3, 20),
(49, 'JARD006', 'Pala', 'Pala de jardín', 3, 25),
(50, 'JARD007', 'Tijeras de Podar', 'Tijeras de podar manuales', 3, 30),
(51, 'JARD008', 'Manguera', 'Manguera de jardín de 20 metros', 3, 15),
(52, 'JARD009', 'Regadera', 'Regadera de plástico', 3, 18),
(53, 'JARD010', 'Carretilla', 'Carretilla de jardín', 3, 10),
(54, 'PLOM001', 'Llave de Tubo', 'Llave de tubo ajustable', 4, 20),
(55, 'PLOM002', 'Cortatubos', 'Cortatubos manual', 4, 15),
(56, 'PLOM003', 'Desatascador', 'Desatascador de goma', 4, 25),
(57, 'PLOM004', 'Llave de Grifa', 'Llave de grifa ajustable', 4, 18),
(58, 'PLOM005', 'Soldador de Tubos', 'Soldador de tubos de plástico', 4, 10),
(59, 'PLOM006', 'Detector de Fugas', 'Detector de fugas de gas', 4, 8),
(60, 'PLOM007', 'Llave de Paso', 'Llave de paso para tuberías', 4, 12),
(61, 'PLOM008', 'Cinta de Teflón', 'Cinta de teflón para sellado', 4, 50),
(62, 'PLOM009', 'Llave de Cruz', 'Llave de cruz para radiadores', 4, 15),
(63, 'PLOM010', 'Llave de Lavabo', 'Llave de lavabo ajustable', 4, 20),
(64, 'PINT001', 'Rodillo de Pintura', 'Rodillo de pintura de 9 pulgadas', 5, 30),
(65, 'PINT002', 'Brocha', 'Brocha de 2 pulgadas', 5, 40),
(66, 'PINT003', 'Pistola de Pintura', 'Pistola de pintura eléctrica', 5, 10),
(67, 'PINT004', 'Lijadora', 'Lijadora manual', 5, 25),
(68, 'PINT005', 'Espátula', 'Espátula de acero', 5, 35),
(69, 'PINT006', 'Cinta de Pintor', 'Cinta de pintor de 50 metros', 5, 50),
(70, 'PINT007', 'Bandeja de Pintura', 'Bandeja de pintura de plástico', 5, 20),
(71, 'PINT008', 'Rascador de Pintura', 'Rascador de pintura manual', 5, 15),
(72, 'PINT009', 'Papel de Lija', 'Papel de lija de grano fino', 5, 100),
(73, 'PINT010', 'Mascarilla', 'Mascarilla para pintura', 5, 50),
(74, 'CONS001', 'Cemento', 'Saco de cemento de 50 kg', 6, 100),
(75, 'CONS002', 'Arena', 'Saco de arena de 50 kg', 6, 100),
(76, 'CONS003', 'Grava', 'Saco de grava de 50 kg', 6, 100),
(77, 'CONS004', 'Ladrillo', 'Ladrillo de construcción', 6, 500),
(78, 'CONS005', 'Bloque de Hormigón', 'Bloque de hormigón de 20x20x40 cm', 6, 300),
(79, 'CONS006', 'Viga de Acero', 'Viga de acero de 6 metros', 6, 50),
(80, 'CONS007', 'Malla Electrosoldada', 'Malla electrosoldada de 2x3 metros', 6, 100),
(81, 'CONS008', 'Tubo de PVC', 'Tubo de PVC de 3 metros', 6, 200),
(82, 'CONS009', 'Tubo de Cobre', 'Tubo de cobre de 3 metros', 6, 150),
(83, 'CONS010', 'Tubo de Hierro', 'Tubo de hierro de 3 metros', 6, 100),
(84, 'AUTO001', 'Llave de Ruedas', 'Llave de ruedas cruz', 7, 20),
(85, 'AUTO002', 'Gato Hidráulico', 'Gato hidráulico de 2 toneladas', 7, 15),
(86, 'AUTO003', 'Compresor de Aire', 'Compresor de aire portátil', 7, 10),
(87, 'AUTO004', 'Manómetro', 'Manómetro para neumáticos', 7, 25),
(88, 'AUTO005', 'Cargador de Baterías', 'Cargador de baterías de coche', 7, 12),
(89, 'AUTO006', 'Arrancador de Baterías', 'Arrancador de baterías portátil', 7, 8),
(90, 'AUTO007', 'Llave Dinamométrica', 'Llave dinamométrica ajustable', 7, 10),
(91, 'AUTO008', 'Extractor de Rodamientos', 'Extractor de rodamientos manual', 7, 15),
(92, 'AUTO009', 'Elevador de Coches', 'Elevador de coches hidráulico', 7, 5),
(93, 'AUTO010', 'Pistola de Impacto', 'Pistola de impacto neumática', 7, 10),
(94, 'AUTO011', 'Llave de Filtro de Aceite', 'Llave de filtro de aceite ajustable', 7, 20),
(95, 'AUTO012', 'Bomba de Vacío', 'Bomba de vacío para frenos', 7, 10),
(96, 'AUTO013', 'Extractor de Volante', 'Extractor de volante manual', 7, 8),
(97, 'AUTO014', 'Llave de Bujías', 'Llave de bujías ajustable', 7, 25),
(98, 'AUTO015', 'Medidor de Compresión', 'Medidor de compresión para motores', 7, 10),
(99, 'AUTO016', 'Llave de Tuercas', 'Llave de tuercas ajustable', 7, 30),
(100, 'AUTO017', 'Extractor de Poleas', 'Extractor de poleas manual', 7, 12),
(101, 'AUTO018', 'Llave de Vaso', 'Juego de llaves de vaso', 7, 40),
(102, 'AUTO019', 'Llave de Impacto', 'Llave de impacto eléctrica', 7, 10),
(103, 'AUTO020', 'Llave de Torque', 'Llave de torque ajustable', 7, 15),
(104, 'PL45043', 'Alicate', 'Cortadora de Hierro', 1, 30),
(107, '0002N2', 'Martillo', 'Martillo de Piso', 4, 7),
(108, '0000002535', 'Llave inglesa', 'Llave inglesa #16', 4, 30),
(109, '000132', 'clavos 1p', 'clavos de una pulgada', 2, 1289),
(110, 'CL0001', 'Cerveza Regia', '750 ml', 1, 23);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramientas_proyectos`
--

CREATE TABLE `herramientas_proyectos` (
  `id_asignacion` int(11) NOT NULL,
  `id_herramienta` int(11) DEFAULT NULL,
  `id_proyecto` int(11) DEFAULT NULL,
  `cantidad_asignada` int(11) NOT NULL,
  `fecha_prestamo` date DEFAULT NULL,
  `devuelta` tinyint(1) DEFAULT 0,
  `cantidad_devuelta` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramientas_proyectos`
--

INSERT INTO `herramientas_proyectos` (`id_asignacion`, `id_herramienta`, `id_proyecto`, `cantidad_asignada`, `fecha_prestamo`, `devuelta`, `cantidad_devuelta`) VALUES
(32, 1, 10, 1, '2024-10-25', 0, 0),
(49, 10, 1, 2, NULL, 0, 0);

--
-- Disparadores `herramientas_proyectos`
--
DELIMITER $$
CREATE TRIGGER `actualizar_cantidad_herramienta` AFTER INSERT ON `herramientas_proyectos` FOR EACH ROW BEGIN
    UPDATE herramientas
    SET cantidad = cantidad - NEW.cantidad_asignada
    WHERE id_herramienta = NEW.id_herramienta;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `id_proyecto` int(11) NOT NULL,
  `nombre_proyecto` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_prestamo` date NOT NULL,
  `fecha_entrega` date DEFAULT NULL,
  `id_trabajador` int(11) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`id_proyecto`, `nombre_proyecto`, `descripcion`, `fecha_prestamo`, `fecha_entrega`, `id_trabajador`, `estado`) VALUES
(1, 'Instalación de Sistema Eléctrico', 'Instalación de un sistema eléctrico en un edificio comercial', '2024-01-15', '2024-06-15', 1, 'Finalizado'),
(2, 'Construcción de Muebles', 'Construcción de muebles personalizados para una oficina', '2024-02-01', '2024-07-01', 2, 'Finalizado'),
(3, 'Reparación de Tuberías', 'Reparación de tuberías en una comunidad residencial', '2024-03-10', '2024-12-10', 3, 'Finalizado'),
(4, 'Pintura de Interiores', 'Pintura de interiores de una casa', '2024-04-05', '2024-09-05', 4, 'Finalizado'),
(5, 'Mantenimiento de Jardines', 'Mantenimiento de jardines en un parque público', '2024-05-20', '2024-10-20', 5, 'Finalizado'),
(6, 'Construcción de Edificio', 'Construcción de un edificio de oficinas', '2024-06-15', '2024-11-15', 6, 'En Proceso'),
(7, 'Reparación de Vehículos', 'Reparación de vehículos en un taller automotriz', '2024-07-01', '2024-12-01', 7, 'En Proceso'),
(8, 'Instalación de Paneles Solares', 'Instalación de paneles solares en una fábrica', '2024-08-10', '2025-01-10', 8, 'En Proceso'),
(9, 'Construcción de Parque', 'Construcción de un parque recreativo', '2024-09-05', '2025-03-05', 9, 'En Proceso'),
(10, 'Desarrollo de Software', 'Desarrollo de software para gestión de inventarios', '2024-10-20', '2025-04-20', 10, 'En Proceso'),
(11, 'Implementación de CRM', 'Implementación de un sistema CRM en una empresa', '2024-11-15', '2025-05-15', 11, 'En Proceso'),
(12, 'Desarrollo de Aplicación Móvil', 'Desarrollo de una aplicación móvil para comercio electrónico', '2024-12-01', '2025-06-01', 12, 'En Proceso'),
(13, 'Construcción de Centro de Datos', 'Construcción de un centro de datos para una empresa de tecnología', '2025-01-10', '2025-07-10', 13, 'En Proceso'),
(14, 'Optimización de Procesos', 'Optimización de procesos de manufactura en una fábrica', '2025-02-05', '2025-08-05', 14, 'En Proceso'),
(15, 'Instalación de Sistema de Seguridad', 'Instalación de un sistema de seguridad en un edificio residencial', '2025-03-20', '2025-09-20', 15, 'En Proceso'),
(16, 'Desarrollo de Plataforma de E-commerce', 'Desarrollo de una plataforma de comercio electrónico', '2025-04-15', '2025-10-15', 16, 'En Proceso'),
(17, 'Implementación de ERP', 'Implementación de un sistema ERP en una empresa manufacturera', '2025-05-01', '2025-11-01', 17, 'En Proceso'),
(18, 'Construcción de Planta de Energía Solar', 'Construcción de una planta de energía solar', '2025-06-10', '2025-12-10', 18, 'En Proceso'),
(19, 'Desarrollo de Sistema de Gestión de Calidad', 'Desarrollo de un sistema de gestión de calidad para una empresa', '2025-07-05', '2026-01-05', 19, 'En Proceso'),
(20, 'Desarrollo de Software de Análisis de Datos', 'Desarrollo de software para análisis de datos en una empresa de tecnología', '2025-08-20', '2026-02-20', 20, 'En Proceso'),
(21, 'Reparación de Red Eléctrica', 'Reparación de la red eléctrica en una comunidad', '2025-09-01', '2026-02-01', 1, 'En Proceso'),
(22, 'Construcción de Puente', 'Construcción de un puente peatonal', '2025-10-15', '2026-04-15', 2, 'En Proceso'),
(23, 'Mantenimiento de Flota Vehicular', 'Mantenimiento de la flota vehicular de una empresa', '2025-11-10', '2026-05-10', 3, 'En Proceso'),
(24, 'Instalación de Sistema de Riego', 'Instalación de un sistema de riego en un parque', '2025-12-05', '2026-06-05', 4, 'En Proceso'),
(25, 'Reparación de Techo', 'Reparación del techo de un edificio', '2026-01-20', '2026-07-20', 5, 'En Proceso'),
(26, 'Construcción de Piscina', 'Construcción de una piscina en un complejo residencial', '2026-02-15', '2026-08-15', 6, 'En Proceso'),
(27, 'Desarrollo de Sistema de Facturación', 'Desarrollo de un sistema de facturación para una empresa', '2026-03-10', '2026-09-10', 7, 'En Proceso'),
(28, 'Implementación de Sistema de Videovigilancia', 'Implementación de un sistema de videovigilancia en una fábrica', '2026-04-05', '2026-10-05', 8, 'En Proceso'),
(29, 'Reparación de Maquinaria Industrial', 'Reparación de maquinaria industrial en una planta de producción', '2026-05-01', '2026-11-01', 9, 'En Proceso'),
(30, 'Construcción de Carretera', 'Construcción de una carretera en una zona rural', '2026-06-20', '2026-12-20', 10, 'En Proceso'),
(31, 'Muro perimetral', 'Levantamiento de muro perimetral en molsa s.s', '2024-09-05', '2025-01-31', 10, NULL),
(32, 'Reparación de Acera ', 'reparacion de acera av roosvelt', '2024-08-06', '2024-11-10', 16, 'Finalizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trabajadores`
--

CREATE TABLE `trabajadores` (
  `id_trabajador` int(11) NOT NULL,
  `nombre_trabajador` varchar(100) NOT NULL,
  `puesto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `trabajadores`
--

INSERT INTO `trabajadores` (`id_trabajador`, `nombre_trabajador`, `puesto`) VALUES
(3, 'Carlos García', 'Plomero'),
(4, 'Ana Martínez', 'Pintora'),
(5, 'Luis Rodríguez', 'Jardinero'),
(6, 'Sofía Hernández', 'Constructora'),
(7, 'Miguel Fernández', 'Automotriz'),
(8, 'Laura Gómez', 'Electricista'),
(9, 'David Díaz', 'Carpintero'),
(10, 'Elena Torres', 'Plomera'),
(11, 'José Ramírez', 'Pintor'),
(12, 'Isabel Sánchez', 'Jardinera'),
(13, 'Pedro Morales', 'Constructor'),
(14, 'Lucía Ortiz', 'Automotriz'),
(15, 'Javier Castillo', 'Electricista'),
(16, 'Axel Hernández ', 'Carpintero'),
(17, 'Arturo Ventura', 'Ingeniero'),
(18, 'Fatima Gaméz', 'Jardinera');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `password`, `rol`) VALUES
(1, 'Brittanny Samper', 'Hola123', 'admin'),
(2, 'Jose', '12234', 'admin'),
(6, 'ivillalta', 'Villalta.824', 'admin'),
(7, 'Jventura', 'admin123', 'user'),
(8, 'jonagay', '1234', 'admin'),
(9, 'wiled33', '1234', 'admin');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_herramientas_proyecto`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_herramientas_proyecto` (
`nombre_proyecto` varchar(100)
,`herramienta` varchar(100)
,`nombre_trabajador` varchar(100)
,`cantidad_asignada` int(11)
,`cantidad_devuelta` int(11)
,`fecha_prestamo` date
,`fecha_entrega` date
,`estado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_herramientas_proyecto`
--
DROP TABLE IF EXISTS `vista_herramientas_proyecto`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_herramientas_proyecto`  AS SELECT `p`.`nombre_proyecto` AS `nombre_proyecto`, `h`.`nombre` AS `herramienta`, `t`.`nombre_trabajador` AS `nombre_trabajador`, `hp`.`cantidad_asignada` AS `cantidad_asignada`, `hp`.`cantidad_devuelta` AS `cantidad_devuelta`, `p`.`fecha_prestamo` AS `fecha_prestamo`, `p`.`fecha_entrega` AS `fecha_entrega`, `p`.`estado` AS `estado` FROM (((`proyectos` `p` join `herramientas_proyectos` `hp` on(`p`.`id_proyecto` = `hp`.`id_proyecto`)) join `herramientas` `h` on(`hp`.`id_herramienta` = `h`.`id_herramienta`)) join `trabajadores` `t` on(`p`.`id_trabajador` = `t`.`id_trabajador`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  ADD PRIMARY KEY (`id_herramienta`),
  ADD UNIQUE KEY `codigo_herramienta` (`codigo_herramienta`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `herramientas_proyectos`
--
ALTER TABLE `herramientas_proyectos`
  ADD PRIMARY KEY (`id_asignacion`),
  ADD KEY `id_herramienta` (`id_herramienta`),
  ADD KEY `id_proyecto` (`id_proyecto`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`id_proyecto`),
  ADD KEY `id_trabajador` (`id_trabajador`);

--
-- Indices de la tabla `trabajadores`
--
ALTER TABLE `trabajadores`
  ADD PRIMARY KEY (`id_trabajador`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  MODIFY `id_herramienta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT de la tabla `herramientas_proyectos`
--
ALTER TABLE `herramientas_proyectos`
  MODIFY `id_asignacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `id_proyecto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `trabajadores`
--
ALTER TABLE `trabajadores`
  MODIFY `id_trabajador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
