<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener lista de empleados (trabajadores)
$empleados = $conn->query("SELECT id_trabajador, nombre_trabajador FROM trabajadores");

// Manejar adición de proyectos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_proyecto = $_POST['nombre_proyecto'];
    $descripcion = $_POST['descripcion'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];
    $id_empleado = $_POST['id_empleado'];

    // Validar y agregar nuevo proyecto con fechas e id_empleado
    $stmt = $conn->prepare("INSERT INTO proyectos (nombre_proyecto, descripcion, fecha_prestamo, fecha_entrega, id_trabajador) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $nombre_proyecto, $descripcion, $fecha_inicio, $fecha_fin, $id_empleado);

    if ($stmt->execute()) {
        echo "<script>alert('Proyecto agregado exitosamente.'); window.location.href='proyectos.php';</script>";
    } else {
        echo "<script>alert('Error al agregar el proyecto: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Proyecto</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    .navbar {
        background-color: blue;
        overflow: hidden;
        position: relative;
        z-index: 1000;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: skyblue;
    }

    .navbar .user-info {
        float: right;
        position: relative;
    }

    .navbar .user-info .user-icon {
        cursor: pointer;
    }

    .navbar .user-info .dropdown {
        display: none;
        position: fixed;
        top: 50px;
        right: 20px;
        background-color: white;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1001;
    }

    .navbar .user-info .dropdown a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .navbar .user-info .dropdown a:hover {
        background-color: #ddd;
    }

    .navbar .user-info:hover .dropdown {
        display: block;
    }

    .form-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        max-width: 500px;
        margin: 40px auto;
        box-sizing: border-box;
    }

    .form-container h2 {
        margin-bottom: 20px;
        color: blue;
    }

    .form-container input, .form-container select, .form-container textarea {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    .form-container button {
        width: 100%;
        padding: 10px;
        background-color: blue;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        box-sizing: border-box;
    }

    .form-container button:hover {
        background-color: skyblue;
    }

    .user-icon {
        font-size: 40px;
    }

    @media (max-width: 600px) {
        .navbar a {
            float: none;
            display: block;
            text-align: left;
        }

        .navbar .user-info {
            float: none;
        }

        .navbar .user-info .dropdown {
            position: static;
            min-width: 100%;
        }

        .form-container {
            padding: 15px;
        }

        .form-container input, .form-container select, .form-container textarea, .form-container button {
            padding: 8px;
        }
    }
</style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });
    </script>
    <script>
        function confirmarCierreSesion(event) {
            if (!confirm("¿Estás seguro de que deseas cerrar sesión?")) {
                event.preventDefault();
            }
        }
    </script>
</head>
<body>
<div class="navbar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php" onclick="confirmarCierreSesion(event)">Cerrar Sesión</a>
        </div>
    </div>
</div>
<div class="form-container">
    <h2>Agregar Proyecto</h2>
    <form action="agregar_proyecto.php" method="POST">
        <input type="text" name="nombre_proyecto" placeholder="Nombre del Proyecto" required>
        <textarea name="descripcion" placeholder="Descripción del Proyecto" required></textarea>
        <label for="fecha_inicio">Fecha de Inicio:</label>
        <input type="date" name="fecha_inicio" required>
        <label for="fecha_fin">Fecha de Finalización:</label>
        <input type="date" name="fecha_fin">

        <label for="id_empleado">Asignar Trabajador:</label>
        <select name="id_empleado" required>
            <option value="">Selecciona un Trabajador</option>
            <?php
            if ($empleados->num_rows > 0) {
                while($row = $empleados->fetch_assoc()) {
                    echo "<option value='" . $row['id_trabajador'] . "'>" . $row['nombre_trabajador'] . "</option>";
                }
            }
            ?>
        </select>

        <button type="submit">Agregar</button>
    </form>
</div>
</body>
</html>

<?php
$conn->close();
?>
