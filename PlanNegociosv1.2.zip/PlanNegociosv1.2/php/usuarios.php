<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['rol'] !== 'admin') {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar adición de usuarios
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    $id = $_POST['id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    if ($action == 'add') {
        // Agregar nuevo usuario
        $stmt = $conn->prepare("INSERT INTO usuarios (username, password, rol) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $password, $rol);
        $stmt->execute();
        $stmt->close();
    } elseif ($action == 'edit') {
        // Editar usuario existente
        $stmt = $conn->prepare("UPDATE usuarios SET username = ?, password = ?, rol = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $password, $rol, $id);
        $stmt->execute();
        $stmt->close();
    } elseif ($action == 'delete') {
        // Eliminar usuario
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: usuarios.php");
    exit;
}

// Obtener lista de usuarios
$usuarios = $conn->query("SELECT id, username, rol FROM usuarios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        
        .navbar {
            background-color: blue;
            overflow: hidden;
            position: relative;
            z-index: 1000;
        }
        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: skyblue;
        }
        .navbar .user-info {
            float: right;
            position: relative;
        }
        .navbar .user-info .user-icon {
            cursor: pointer;
        }
        .navbar .user-info .dropdown {
            display: none;
            position: fixed;
            top: 50px;
            right: 20px;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1001;
        }
        .navbar .user-info .dropdown a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }
        .navbar .user-info .dropdown a:hover {
            background-color: #ddd;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 40px auto;
        }
        .form-container h2 {
            margin-bottom: 20px;
            color: blue;
        }
        .form-container input, .form-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: skyblue;
        }
        .user-icon {
            font-size: 40px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: blue;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .action-buttons button {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-button {
            background-color: orange;
            color: white;
        }
        .delete-button {
            background-color: red;
            color: white;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function editUser(id, username, rol) {
            document.getElementById('id').value = id;
            document.getElementById('username').value = username;
            document.getElementById('password').value = '';
            document.getElementById('rol').value = rol;
            document.getElementById('action').value = 'edit';
        }

        function deleteUser(id) {
            if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
                document.getElementById('id').value = id;
                document.getElementById('action').value = 'delete';
                document.getElementById('userForm').submit();
            }
        }
    </script>
</head>
<body>
<div class="navbar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php">Cerrar Sesión</a>
        </div>
    </div>
</div>
<div class="form-container">
    <h2>Agregar Usuario</h2>
    <form id="userForm" action="usuarios.php" method="POST">
        <input type="hidden" id="id" name="id">
        <input type="hidden" id="action" name="action" value="add">
        <input type="text" id="username" name="username" placeholder="Nombre de Usuario" required>
        <input type="password" id="password" name="password" placeholder="Contraseña" required>
        <select id="rol" name="rol" required>
            <option value="admin">Admin</option>
            <option value="inventario">Inventario</option>
            <option value="proyectos">Proyectos</option>
        </select>
        <button type="submit">Agregar</button>
    </form>
</div>

<h2>Lista de Usuarios</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre de Usuario</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $usuarios->fetch_assoc()) : ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['rol']; ?></td>
            <td>
                <div class="action-buttons">
                    <button class="edit-button" onclick="editUser('<?php echo $row['id']; ?>', '<?php echo $row['username']; ?>', '<?php echo $row['rol']; ?>')">Editar</button>
                    <button class="delete-button" onclick="deleteUser('<?php echo $row['id']; ?>')">Eliminar</button>
                </div>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>

<?php
$conn->close();
?>
