<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje_error = "";

// Manejar adición de herramientas
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_herramienta = $_POST['codigo_herramienta'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $id_categoria = $_POST['id_categoria'];
    $cantidad = $_POST['cantidad'];

    // Verificar si el código de herramienta ya existe
    $check_query = "SELECT COUNT(*) FROM herramientas WHERE codigo_herramienta = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $codigo_herramienta);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count == 0) {
        // No hay duplicado, proceder con la inserción
        $insert_query = "INSERT INTO herramientas (codigo_herramienta, nombre, descripcion, id_categoria, cantidad) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("sssii", $codigo_herramienta, $nombre, $descripcion, $id_categoria, $cantidad);
        $stmt->execute();
        $stmt->close();

        header("Location: inventario.php");
        exit;
    } else {
        $mensaje_error = "Entrada duplicada encontrada para codigo_herramienta: " . $codigo_herramienta;
    }
}

// Obtener lista de categorías
$categorias = $conn->query("SELECT id_categoria, nombre_categoria FROM categorias");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Inventario</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    .navbar {
        background-color: blue;
        overflow: hidden;
        position: relative;
        z-index: 1000;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: skyblue;
    }

    .navbar .user-info {
        float: right;
        position: relative;
    }

    .navbar .user-info .user-icon {
        cursor: pointer;
    }

    .navbar .user-info .dropdown {
        display: none;
        position: fixed;
        top: 50px;
        right: 20px;
        background-color: white;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1001;
    }

    .navbar .user-info .dropdown a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .navbar .user-info .dropdown a:hover {
        background-color: #ddd;
    }

    .navbar .user-info:hover .dropdown {
        display: block;
    }

    .form-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        max-width: 500px;
        margin: 40px auto;
        box-sizing: border-box;
    }

    .form-container h2 {
        margin-bottom: 20px;
        color: blue;
    }

    .form-container input, .form-container select {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    .form-container button {
        width: 100%;
        padding: 10px;
        background-color: blue;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        box-sizing: border-box;
    }

    .form-container button:hover {
        background-color: skyblue;
    }

    .user-icon {
        font-size: 40px;
    }

    @media (max-width: 600px) {
        .navbar a {
            float: none;
            display: block;
            text-align: left;
        }

        .navbar .user-info {
            float: none;
        }

        .navbar .user-info .dropdown {
            position: static;
            min-width: 100%;
        }

        .form-container {
            padding: 15px;
        }

        .form-container input, .form-container select, .form-container button {
            padding: 8px;
        }
    }
</style>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#proyectos').DataTable();
            $('#inventario').DataTable();
        });

        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function openInventoryModal(projectId) {
            $('#projectId').val(projectId);
            $('#inventoryModal').modal('show');
        }

        function addToolToProject(toolId, toolName) {
            var projectId = $('#projectId').val();
            $.post('agregar_herramienta_proyecto.php', { projectId: projectId, toolId: toolId }, function(response) {
                alert(response);
                $('#inventoryModal').modal('hide');
                // Actualizar la tabla de detalles del proyecto
                var newRow = `<tr>
                                <td>${toolId}</td>
                                <td>${toolName}</td>
                              </tr>`;
                $('#projectDetails tbody').append(newRow);
            });
        }
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });
    </script>
    
    <script>
        function mostrarAlerta(mensaje) {
            alert(mensaje);
        }

        function confirmarCierreSesion(event) {
            if (!confirm("¿Estás seguro de que deseas cerrar sesión?")) {
                event.preventDefault();
            }
        }
    </script>
    <script>
        function mostrarAlerta(mensaje) {
            alert(mensaje);
        }

        function confirmarCierreSesion(event) {
            if (!confirm("¿Estás seguro de que deseas cerrar sesión?")) {
                event.preventDefault();
            }
        }
    </script>
</head>
<body>
<div class="navbar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php" onclick="confirmarCierreSesion(event)">Cerrar Sesión</a>
        </div>
    </div>
</div>
<div class="form-container">
    <h2>Agregar Inventario</h2>
    <?php if ($mensaje_error): ?>
        <script>
            mostrarAlerta("<?php echo $mensaje_error; ?>");
        </script>
    <?php endif; ?>
    <form action="agregarinventario.php" method="POST">
        <input type="text" name="codigo_herramienta" placeholder="Código de Herramienta" required>
        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="text" name="descripcion" placeholder="Descripción" required>
        <select name="id_categoria" required>
            <?php
            while ($row = $categorias->fetch_assoc()) {
                echo "<option value='{$row['id_categoria']}'>{$row['nombre_categoria']}</option>";
            }
            ?>
        </select>
        <input type="number" name="cantidad" placeholder="Cantidad" required>
        <button type="submit" name="addinventory">Agregar</button>
    </form>
</div>
</body>
</html>

<?php
$conn->close();
?>
