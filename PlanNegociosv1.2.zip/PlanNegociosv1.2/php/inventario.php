<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_bodega";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar actualización de stock
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_stock'])) {
    $id_herramienta = $_POST['id_herramienta'];
    $cantidad_modificacion = intval($_POST['cantidad_modificacion']);
    $accion = $_POST['accion'];  // Puede ser "agregar" o "reducir"

    // Obtener la cantidad actual de la herramienta
    $result = $conn->query("SELECT cantidad FROM herramientas WHERE id_herramienta = $id_herramienta");
    $herramienta = $result->fetch_assoc();

    if ($herramienta) {
        $cantidad_actual = $herramienta['cantidad'];

        // Determinar la nueva cantidad
        if ($accion == 'agregar') {
            $nueva_cantidad = $cantidad_actual + $cantidad_modificacion;
        } elseif ($accion == 'reducir' && $cantidad_modificacion <= $cantidad_actual) {
            $nueva_cantidad = $cantidad_actual - $cantidad_modificacion;
        } else {
            echo "No se puede reducir más de la cantidad disponible.";
            exit;
        }

        // Actualizar la cantidad en la base de datos
        $conn->query("UPDATE herramientas SET cantidad = $nueva_cantidad WHERE id_herramienta = $id_herramienta");
        header("Location: inventario.php");
        exit;
    }
}

// Manejar filtro por categoría
$categoria = "";
$where_clause = "";
if (isset($_GET['categoria']) && !empty($_GET['categoria'])) {
    $categoria = $conn->real_escape_string($_GET['categoria']);
    $where_clause = "WHERE c.nombre_categoria LIKE '%$categoria%'";
}

// Obtener lista de herramientas con filtro si se ha especificado una categoría
$query = "SELECT h.id_herramienta, h.codigo_herramienta, h.nombre, h.descripcion, c.nombre_categoria, h.cantidad 
          FROM herramientas h
          JOIN categorias c ON h.id_categoria = c.id_categoria
          $where_clause";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de herramientas</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    h1 {
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: blue;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .actions a {
        margin: 0 5px;
        text-decoration: none;
        color: red;
    }

    .actions a:hover {
        color: black;
    }

    .add-button {
        display: inline-block;
        padding: 10px 20px;
        margin-bottom: 20px;
        background: blue;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }

    .add-button:hover {
        background: skyblue;
    }

    .user-icon {
        font-size: 40px;
    }

    .nav-bar {
        background-color: blue;
        overflow: hidden;
        position: relative;
        z-index: 1000;
    }

    .nav-bar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .nav-bar a:hover {
        background-color: skyblue;
    }

    .nav-bar .user-info {
        float: right;
        position: relative;
    }

    .nav-bar .user-info .user-icon {
        cursor: pointer;
    }

    .btn-agregar {
        background-color: green;
    }

    .btn-reducir {
        background-color: red;
    }

    .actions button {
        margin: 0 5px;
        padding: 5px 10px;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 4px;
    }

    .nav-bar .user-info .dropdown {
        display: none;
        position: fixed;
        top: 50px;
        right: 20px;
        background-color: white;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1001;
    }

    .nav-bar .user-info .dropdown a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .nav-bar .user-info .dropdown a:hover {
        background-color: #ddd;
    }

    .nav-bar .user-info:hover .dropdown {
        display: block;
    }

    #stockModal {
        display: none; 
        position: fixed; 
        z-index: 1; 
        left: 0; 
        top: 0; 
        width: 100%; 
        height: 100%; 
        overflow: auto; 
        background-color: rgb(0,0,0); 
        background-color: rgba(0,0,0,0.4); 
    }

    #stockModalContent {
        background-color: #fefefe;
        margin: 15% auto; 
        padding: 20px;
        border: 1px solid #888;
        width: 80%; 
        max-width: 500px; 
        border-radius: 10px;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    @media (max-width: 600px) {
        .nav-bar a {
            float: none;
            display: block;
            text-align: left;
        }

        .nav-bar .user-info {
            float: none;
        }

        .nav-bar .user-info .dropdown {
            position: static;
            min-width: 100%;
        }

        table, th, td {
            padding: 8px;
        }

        .add-button {
            padding: 8px 16px;
        }

        .actions a, .actions button {
            padding: 5px;
        }

        #stockModalContent {
            width: 90%;
        }
    }
</style>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#proyectos').DataTable();
            $('#inventario').DataTable();
        });

        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function openInventoryModal(projectId) {
            $('#projectId').val(projectId);
            $('#inventoryModal').modal('show');
        }

        function addToolToProject(toolId, toolName) {
            var projectId = $('#projectId').val();
            $.post('agregar_herramienta_proyecto.php', { projectId: projectId, toolId: toolId }, function(response) {
                alert(response);
                $('#inventoryModal').modal('hide');
                // Actualizar la tabla de detalles del proyecto
                var newRow = `<tr>
                                <td>${toolId}</td>
                                <td>${toolName}</td>
                              </tr>`;
                $('#projectDetails tbody').append(newRow);
            });
        }
    </script>
</head>
<body>
<div class="nav-bar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php">Cerrar Sesión</a>
        </div>
    </div>
</div>

<h1>Gestión de herramientas</h1>
<a href="agregarinventario.php" class="add-button">Agregar Inventario</a>

<form method="GET" action="inventario.php">
    <label for="categoria">Buscar por categoría:</label>
    <input type="text" id="categoria" name="categoria" value="<?php echo htmlspecialchars($categoria); ?>">
    <button type="submit">Buscar</button>
</form>

<table id="inventario" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Código</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Categoría</th>
            <th>Cantidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
            <td><?php echo $row['id_herramienta']; ?></td>
            <td><?php echo $row['codigo_herramienta']; ?></td>
            <td><?php echo $row['nombre']; ?></td>
            <td><?php echo $row['descripcion']; ?></td>
            <td><?php echo $row['nombre_categoria']; ?></td>
            <td><?php echo $row['cantidad']; ?></td>
            <td class='actions'>
                <button class="btn-agregar" onclick="openModal(<?php echo $row['id_herramienta']; ?>, 'agregar', '<?php echo $row['nombre']; ?>')">Agregar Stock</button>
                <button class="btn-reducir" onclick="openModal(<?php echo $row['id_herramienta']; ?>, 'reducir', '<?php echo $row['nombre']; ?>')">Reducir Stock</button>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<!-- Modal para modificar stock -->
<div id="stockModal">
    <div id="stockModalContent">
        <span class="close" onclick="closeModal()">×</span>
        <h2 id="modalTitle"></h2>
        <form id="stockForm" method="POST" action="inventario.php">
            <input type="hidden" id="id_herramienta" name="id_herramienta">
            <input type="hidden" id="accion" name="accion">
            <label for="cantidad_modificacion">Cantidad:</label>
            <input type="number" id="cantidad_modificacion" name="cantidad_modificacion" required>
            <button type="submit" name="update_stock">Actualizar Stock</button>
            <button type="button" onclick="closeModal()">Cancelar</button>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#inventario').DataTable();
});

function openModal(id, accion, nombre) {
    console.log("Abriendo modal para ID:", id, "Acción:", accion, "Nombre:", nombre);
    document.getElementById('id_herramienta').value = id;
    document.getElementById('accion').value = accion;
    document.getElementById('modalTitle').innerText = (accion === 'agregar' ? 'Agregar Stock a ' : 'Reducir Stock de ') + nombre;
    document.getElementById('stockModal').style.display = 'block';
}

function closeModal() {
    console.log("Cerrando modal");
    document.getElementById('stockModal').style.display = 'none';
}

// Cerrar el modal si el usuario hace clic fuera de él
window.onclick = function(event) {
    if (event.target == document.getElementById('stockModal')) {
        closeModal();
    }
}
</script>

</body>
</html>

<?php
$conn->close();
?>