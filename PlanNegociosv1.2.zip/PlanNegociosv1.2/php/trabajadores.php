<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['rol'] !== 'admin') {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar adición, edición y eliminación de trabajadores
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    $id_trabajador = $_POST['id_trabajador'];
    $nombre_trabajador = $_POST['nombre_trabajador'];
    $puesto = $_POST['puesto'];

    if ($action == 'add') {
        // Agregar nuevo trabajador
        $stmt = $conn->prepare("INSERT INTO trabajadores (nombre_trabajador, puesto) VALUES (?, ?)");
        $stmt->bind_param("ss", $nombre_trabajador, $puesto);
        $stmt->execute();
        $stmt->close();
    } elseif ($action == 'edit') {
        // Editar trabajador existente
        $stmt = $conn->prepare("UPDATE trabajadores SET nombre_trabajador = ?, puesto = ? WHERE id_trabajador = ?");
        $stmt->bind_param("ssi", $nombre_trabajador, $puesto, $id_trabajador);
        $stmt->execute();
        $stmt->close();
    } elseif ($action == 'delete') {
        // Eliminar trabajador
        $stmt = $conn->prepare("DELETE FROM trabajadores WHERE id_trabajador = ?");
        $stmt->bind_param("i", $id_trabajador);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: trabajadores.php");
    exit;
}

// Obtener lista de trabajadores
$trabajadores = $conn->query("SELECT id_trabajador, nombre_trabajador, puesto FROM trabajadores");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabajadores</title>
    <!-- Incluir CSS de DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- Incluir jQuery -->
    <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <!-- Incluir JS de DataTables -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .actions button {
            margin: 0 5px;
            padding: 5px 10px;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
        .btn-agregar {
            background-color: green;
        }
        .btn-reducir {
            background-color: red;
        }
        
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: blue;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .actions a {
            margin: 0 5px;
            text-decoration: none;
            color: red;
        }
        .actions a:hover {
            color: black;
        }
        .add-button {
            display: inline-block;
            padding: 10px 20px;
            margin-bottom: 20px;
            background: blue;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .add-button:hover {
            background: skyblue;
        }
        .user-icon{
            font-size:40px;
        }
        .nav-bar {
            background-color: blue;
            overflow: hidden;
            position: relative;
            z-index: 1000;
        }
        .nav-bar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .nav-bar a:hover {
            background-color: skyblue;
        }
        .nav-bar .user-info {
            float: right;
            position: relative;
        }
        .nav-bar .user-info .user-icon {
            cursor: pointer;
        }
        .nav-bar .user-info .dropdown {
            display: none;
            position: fixed;
            top: 50px;
            right: 20px;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1001;
        }
        .nav-bar .user-info .dropdown a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }
        .nav-bar .user-info .dropdown a:hover {
            background-color: #ddd;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 40px auto;
        }
        .form-container h2 {
            margin-bottom: 20px;
            color: blue;
        }
        .form-container input, .form-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: skyblue;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .action-buttons button {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-button {
            background-color: orange;
            color: white;
        }
        .delete-button {
            background-color: red;
            color: white;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#proyectos').DataTable();
            $('#inventario').DataTable();
        });

        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function openInventoryModal(projectId) {
            $('#projectId').val(projectId);
            $('#inventoryModal').modal('show');
        }

        function addToolToProject(toolId, toolName) {
            var projectId = $('#projectId').val();
            $.post('agregar_herramienta_proyecto.php', { projectId: projectId, toolId: toolId }, function(response) {
                alert(response);
                $('#inventoryModal').modal('hide');
                // Actualizar la tabla de detalles del proyecto
                var newRow = `<tr>
                                <td>${toolId}</td>
                                <td>${toolName}</td>
                              </tr>`;
                $('#projectDetails tbody').append(newRow);
            });
        }
    </script>
</head>
<body>
<div class="nav-bar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php">Cerrar Sesión</a>
        </div>
    </div>
</div>
<div class="form-container">
    <h2>Agregar Trabajador</h2>
    <form id="workerForm" action="trabajadores.php" method="POST">
        <input type="hidden" id="id_trabajador" name="id_trabajador">
        <input type="hidden" id="action" name="action" value="add">
        <input type="text" id="nombre_trabajador" name="nombre_trabajador" placeholder="Nombre del Trabajador" required>
        <input type="text" id="puesto" name="puesto" placeholder="Puesto" required>
        <button type="submit">Agregar</button>
    </form>
</div>

<h2>Lista de Trabajadores</h2>
<table id="trabajadoresTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Puesto</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $trabajadores->fetch_assoc()) : ?>
        <tr>
            <td><?php echo $row['id_trabajador']; ?></td>
            <td><?php echo $row['nombre_trabajador']; ?></td>
            <td><?php echo $row['puesto']; ?></td>
            <td>
                <div class="action-buttons">
                    <button class="edit-button" onclick="editWorker('<?php echo $row['id_trabajador']; ?>', '<?php echo $row['nombre_trabajador']; ?>', '<?php echo $row['puesto']; ?>')">Editar</button>
                    <button class="delete-button" onclick="deleteWorker('<?php echo $row['id_trabajador']; ?>')">Eliminar</button>
                </div>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<script>
    $(document).ready(function() {
        $('#trabajadoresTable').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por página",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "No hay registros disponibles",
                "infoFiltered": "(filtrado de _MAX_ registros totales)",
                "search": "Buscar:",
                "paginate": {
                    "first": "Primero",
                    "last": "Último",
                    "next": "Siguiente",
                    "previous": "Anterior"
                }
            }
        });
    });

    function editWorker(id, nombre, puesto) {
        document.getElementById('id_trabajador').value = id;
        document.getElementById('nombre_trabajador').value = nombre;
        document.getElementById('puesto').value = puesto;
        document.getElementById('action').value = 'edit';
    }

    function deleteWorker(id) {
        if (confirm('¿Estás seguro de que deseas eliminar este trabajador?')) {
            document.getElementById('id_trabajador').value = id;
            document.getElementById('action').value = 'delete';
            document.getElementById('workerForm').submit();
        }
    }
</script>

</body>
</html>

<?php
$conn->close();
?>
