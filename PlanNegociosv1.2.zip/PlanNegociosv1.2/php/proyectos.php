<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener lista de proyectos
$result = $conn->query("SELECT id_proyecto, nombre_proyecto, descripcion, estado FROM proyectos");

// Obtener lista de herramientas
$herramientas = $conn->query("SELECT id_herramienta, codigo_herramienta, nombre, descripcion, cantidad FROM herramientas");

// Función para finalizar proyecto y devolver herramientas
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['finalizar_proyecto'])) {
    $id_proyecto = $_POST['id_proyecto'];

    // Cambiar estado del proyecto a "Finalizado"
    $conn->query("UPDATE proyectos SET estado='Finalizado' WHERE id_proyecto=$id_proyecto");

    // Devolver herramientas a la tabla de herramientas
    $herramientas_proyecto = $conn->query("SELECT id_herramienta, cantidad_asignada FROM herramientas_proyectos WHERE id_proyecto=$id_proyecto");
    while ($row = $herramientas_proyecto->fetch_assoc()) {
        $id_herramienta = $row['id_herramienta'];
        $cantidad = $row['cantidad_asignada'];
        $conn->query("UPDATE herramientas SET cantidad=cantidad+$cantidad WHERE id_herramienta=$id_herramienta");
    }

    // Eliminar herramientas del proyecto
    $conn->query("DELETE FROM herramientas_proyectos WHERE id_proyecto=$id_proyecto");

    header("Location: proyectos.php");
    exit;
}

// Función para agregar herramienta al proyecto
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_tool'])) {
    $id_proyecto = $_POST['id_proyecto'];
    $id_herramienta = $_POST['id_herramienta'];
    $cantidad = intval($_POST['cantidad']);

    // Verificar si la cantidad es válida
    $result = $conn->query("SELECT cantidad FROM herramientas WHERE id_herramienta=$id_herramienta");
    $herramienta = $result->fetch_assoc();
    if ($herramienta && $herramienta['cantidad'] >= $cantidad) {
        // Reducir la cantidad de la herramienta en la tabla de herramientas
        $conn->query("UPDATE herramientas SET cantidad=cantidad-$cantidad WHERE id_herramienta=$id_herramienta");

        // Agregar la herramienta al proyecto
        $conn->query("INSERT INTO herramientas_proyectos (id_proyecto, id_herramienta, cantidad_asignada) VALUES ($id_proyecto, $id_herramienta, $cantidad)");

        header("Location: proyectos.php");
        exit;
    } else {
        echo "Cantidad no válida.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyectos</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    h1 {
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: blue;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .actions a {
        margin: 0 5px;
        text-decoration: none;
        color: red;
    }

    .actions a:hover {
        color: black;
    }

    .add-button {
        display: inline-block;
        padding: 10px 20px;
        margin-bottom: 20px;
        background: blue;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }

    .add-button:hover {
        background: skyblue;
    }

    .user-icon {
        font-size: 40px;
    }

    .nav-bar {
        background-color: blue;
        overflow: hidden;
        position: relative;
        z-index: 1000;
    }

    .nav-bar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .nav-bar a:hover {
        background-color: skyblue;
    }

    .nav-bar .user-info {
        float: right;
        position: relative;
    }

    .nav-bar .user-info .user-icon {
        cursor: pointer;
    }

    .nav-bar .user-info .dropdown {
        display: none;
        position: fixed;
        top: 50px;
        right: 20px;
        background-color: white;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1001;
    }

    .nav-bar .user-info .dropdown a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .nav-bar .user-info .dropdown a:hover {
        background-color: #ddd;
    }

    .nav-bar .user-info:hover .dropdown {
        display: block;
    }

    @media (max-width: 600px) {
        .nav-bar a {
            float: none;
            display: block;
            text-align: left;
        }

        .nav-bar .user-info {
            float: none;
        }

        .nav-bar .user-info .dropdown {
            position: static;
            min-width: 100%;
        }

        table, th, td {
            padding: 8px;
        }

        .add-button {
            padding: 8px 16px;
        }

        .actions a {
            padding: 5px;
        }
    }
</style>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#proyectos').DataTable();
            $('#inventario').DataTable();
        });

        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function openInventoryModal(projectId) {
            $('#projectId').val(projectId);
            $('#inventoryModal').modal('show');
        }

        function addToolToProject(toolId, toolName) {
            var projectId = $('#projectId').val();
            $.post('agregar_herramienta_proyecto.php', { projectId: projectId, toolId: toolId }, function(response) {
                alert(response);
                $('#inventoryModal').modal('hide');
                // Actualizar la tabla de detalles del proyecto
                var newRow = `<tr>
                                <td>${toolId}</td>
                                <td>${toolName}</td>
                              </tr>`;
                $('#projectDetails tbody').append(newRow);
            });
        }
    </script>

</head>
<body>
<div class="nav-bar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php">Cerrar Sesión</a>
        </div>
    </div>
</div>

<h1>Proyectos</h1>

<a href="agregar_proyecto.php" class="add-button">Agregar Proyecto</a>

<table id="proyectos" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Generar filas de la tabla con los datos de los proyectos
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id_proyecto']}</td>
                    <td>{$row['nombre_proyecto']}</td>
                    <td>{$row['descripcion']}</td>
                    <td>{$row['estado']}</td>
                    <td class='actions'>
                        <a href=\"detalles_proyecto.php?id_proyecto={$row['id_proyecto']}\">Mostrar Detalles</a>
                        <a href=\"#\" onclick=\"openInventoryModal({$row['id_proyecto']})\">Agregar Herramienta</a>
                        <form method='POST' style='display:inline;'>
                            <input type='hidden' name='id_proyecto' value='{$row['id_proyecto']}'>
                            <button type='submit' name='finalizar_proyecto' class='btn btn-success'>Proyecto Finalizado</button>
                        </form>
                    </td>
                  </tr>";
        }
        ?>
    </tbody>
</table>

<!-- Modal para mostrar el inventario -->
<div class="modal fade" id="inventoryModal" tabindex="-1" role="dialog" aria-labelledby="inventoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="inventoryModalLabel">Seleccionar Herramienta</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="projectId">
                <table id="inventario" class="display">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Cantidad Disponible</th>
                            <th>Cantidad a Agregar</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        // Generar filas de la tabla con los datos del inventario
                        while ($row = $herramientas->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['id_herramienta']}</td>
                                    <td>{$row['codigo_herramienta']}</td>
                                    <td>{$row['nombre']}</td>
                                    <td>{$row['descripcion']}</td>
                                    <td>{$row['cantidad']}</td>
                                    <td><input type='number' id='cantidad_{$row['id_herramienta']}' min='1' max='{$row['cantidad']}'></td>
                                    <td>
                                        <button class='btn btn-primary' onclick='addToolToProject({$row['id_herramienta']}, document.getElementById(\"cantidad_{$row['id_herramienta']}\").value)'>Agregar</button>
                                    </td>
                                  </tr>";
                        }
                    ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script>
function openInventoryModal(projectId) {
    document.getElementById('projectId').value = projectId;
    $('#inventoryModal').modal('show');
}

function addToolToProject(id_herramienta, cantidad) {
    var projectId = document.getElementById('projectId').value;
    if (cantidad > 0) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = 'proyectos.php';

        var inputProjectId = document.createElement('input');
        inputProjectId.type = 'hidden';
        inputProjectId.name = 'id_proyecto';
        inputProjectId.value = projectId;
        form.appendChild(inputProjectId);

        var inputHerramientaId = document.createElement('input');
        inputHerramientaId.type = 'hidden';
        inputHerramientaId.name = 'id_herramienta';
        inputHerramientaId.value = id_herramienta;
        form.appendChild(inputHerramientaId);

        var inputCantidad = document.createElement('input');
        inputCantidad.type = 'hidden';
        inputCantidad.name = 'cantidad';
        inputCantidad.value = cantidad;
        form.appendChild(inputCantidad);

        var inputAddTool = document.createElement('input');
        inputAddTool.type = 'hidden';
        inputAddTool.name = 'add_tool';
        inputAddTool.value = 'true';
        form.appendChild(inputAddTool);

        document.body.appendChild(form);
        form.submit();
    } else {
        alert('Por favor, ingrese una cantidad válida.');
    }
}

$(document).ready(function() {
    $('#proyectos').DataTable();
    $('#inventario').DataTable();
});
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$conn->close();
?>
