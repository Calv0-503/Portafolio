<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['rol'] != 'admin') {
    echo "Acceso denegado";
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $projectId = $_POST['projectId'];
    $toolId = $_POST['toolId'];

    // Agregar herramienta al proyecto
    $stmt = $conn->prepare("INSERT INTO herramientas_proyectos (id_proyecto, id_herramienta, cantidad_asignada, fecha_prestamo) VALUES (?, ?, 1, CURDATE())");
    $stmt->bind_param("ii", $projectId, $toolId);

    if ($stmt->execute()) {
        echo "Herramienta agregada exitosamente al proyecto.";
    } else {
        echo "Error al agregar la herramienta al proyecto: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
