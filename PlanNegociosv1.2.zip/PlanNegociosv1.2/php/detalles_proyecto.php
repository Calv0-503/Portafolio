<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";  // Cambia esto a tu usuario de la base de datos
$password = "";  // Cambia esto a tu contraseña de la base de datos
$dbname = "sistema_bodega";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener ID del proyecto
$id_proyecto = $_GET['id_proyecto'];

// Obtener detalles del proyecto con el nombre del trabajador asignado
$proyecto = $conn->query("
    SELECT p.nombre_proyecto, p.descripcion, p.fecha_prestamo, p.fecha_entrega, p.estado, t.nombre_trabajador
    FROM proyectos p
    JOIN trabajadores t ON p.id_trabajador = t.id_trabajador
    WHERE p.id_proyecto = $id_proyecto
")->fetch_assoc();

// Obtener herramientas asignadas al proyecto y agrupar por nombre de herramienta
$herramientas = $conn->query("
    SELECT h.nombre, SUM(hp.cantidad_asignada) AS cantidad_total, SUM(hp.cantidad_devuelta) AS cantidad_devuelta, p.fecha_prestamo, p.fecha_entrega
    FROM herramientas_proyectos hp
    JOIN herramientas h ON hp.id_herramienta = h.id_herramienta
    JOIN proyectos p ON hp.id_proyecto = p.id_proyecto
    WHERE hp.id_proyecto = $id_proyecto
    GROUP BY h.nombre, p.fecha_prestamo, p.fecha_entrega
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Proyecto</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    h1 {
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: blue;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .actions a {
        margin: 0 5px;
        text-decoration: none;
        color: red;
    }

    .actions a:hover {
        color: black;
    }

    .add-button {
        display: inline-block;
        padding: 10px 20px;
        margin-bottom: 20px;
        background: blue;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }

    .add-button:hover {
        background: skyblue;
    }

    .user-icon {
        font-size: 40px;
    }

    .nav-bar {
        background-color: blue;
        overflow: hidden;
        position: relative;
        z-index: 1000;
    }

    .nav-bar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .nav-bar a:hover {
        background-color: skyblue;
    }

    .nav-bar .user-info {
        float: right;
        position: relative;
    }

    .nav-bar .user-info .user-icon {
        cursor: pointer;
    }

    .nav-bar .user-info .dropdown {
        display: none;
        position: fixed;
        top: 50px;
        right: 20px;
        background-color: white;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1001;
    }

    .nav-bar .user-info .dropdown a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .nav-bar .user-info .dropdown a:hover {
        background-color: #ddd;
    }

    .nav-bar .user-info:hover .dropdown {
        display: block;
    }

    @media (max-width: 600px) {
        .nav-bar a {
            float: none;
            display: block;
            text-align: left;
        }

        .nav-bar .user-info {
            float: none;
        }

        .nav-bar .user-info .dropdown {
            position: static;
            min-width: 100%;
        }

        table, th, td {
            padding: 8px;
        }

        .add-button {
            padding: 8px 16px;
        }

        .actions a {
            padding: 5px;
        }
    }
</style>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#proyectos').DataTable();
            $('#inventario').DataTable();
        });

        document.addEventListener('DOMContentLoaded', function() {
            var userIcon = document.querySelector('.user-icon');
            var dropdown = document.querySelector('.dropdown');

            userIcon.addEventListener('click', function() {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            });

            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
                if (!event.target.matches('.user-icon')) {
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    }
                }
            }

            // Confirm before logging out
            var logoutLink = document.querySelector('.logout-link');
            logoutLink.addEventListener('click', function(event) {
                if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    event.preventDefault();
                }
            });
        });

        function openInventoryModal(projectId) {
            $('#projectId').val(projectId);
            $('#inventoryModal').modal('show');
        }

        function addToolToProject(toolId, toolName) {
            var projectId = $('#projectId').val();
            $.post('agregar_herramienta_proyecto.php', { projectId: projectId, toolId: toolId }, function(response) {
                alert(response);
                $('#inventoryModal').modal('hide');
                // Actualizar la tabla de detalles del proyecto
                var newRow = `<tr>
                                <td>${toolId}</td>
                                <td>${toolName}</td>
                              </tr>`;
                $('#projectDetails tbody').append(newRow);
            });
        }
    </script>
</head>
<body>
<div class="nav-bar">
    <img src="../img/asd.jpg" alt="logo" width="60px" height="60px">
    <a href="../html/inicio.html">Inicio</a>
    <a href="inventario.php">Inventarios</a>
    <a href="proyectos.php">Proyectos</a>
    <a href="agregarinventario.php">Agregar Inventario</a>
    <a href="agregar_proyecto.php">Agregar Proyecto</a>
    <?php if ($_SESSION['rol'] === 'admin'): ?>
        <a href="trabajadores.php">Trabajadores</a>
        <a href="usuarios.php">Usuarios</a>
    <?php endif; ?>
    <div class="user-info">
        <span class="user-icon">👤</span>
        <div class="dropdown">
            <a href="#">Nombre de Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="#">Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></a>
            <a href="logout.php" onclick="confirmarCierreSesion(event)">Cerrar Sesión</a>
        </div>
    </div>
</div>

<h1>Detalles del Proyecto</h1>
<h2><?php echo $proyecto['nombre_proyecto']; ?></h2>
<p><?php echo $proyecto['descripcion']; ?></p>
<p>Fecha de Inicio: <?php echo $proyecto['fecha_prestamo']; ?></p>
<p>Fecha de Finalización: <?php echo $proyecto['fecha_entrega']; ?></p>
<p>Estado: <span class="<?php echo $proyecto['estado'] == 'En Proceso' ? 'estado-en-proceso' : 'estado-finalizado'; ?>">
    <?php echo $proyecto['estado']; ?>
</span></p>
<p>Supervisor del Proyecto: <?php echo $proyecto['nombre_trabajador']; ?></p>

<h3>Herramientas Asignadas</h3>
<table>
    <thead>
        <tr>
            <th>Nombre de Herramienta</th>
            <th>Cantidad Total Asignada</th>
            <th>Cantidad Devuelta</th>
            <th>Fecha de Préstamo</th>
            <th>Fecha de Entrega</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Generar filas de la tabla con los datos de las herramientas agrupadas
        while ($row = $herramientas->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['nombre']}</td>
                    <td>{$row['cantidad_total']}</td>
                    <td>{$row['cantidad_devuelta']}</td>
                    <td>{$row['fecha_prestamo']}</td>
                    <td>{$row['fecha_entrega']}</td>
                  </tr>";
        }
        ?>
    </tbody>
</table>

</body>
</html>
<?php
$conn->close();
?>
