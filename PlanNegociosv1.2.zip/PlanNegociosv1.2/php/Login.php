<?php
session_start();

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_bodega";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Validar entrada
    if (empty($user) || empty($pass)) {
        echo "<script>alert('Nombre de usuario y contraseña son requeridos.'); window.location.href='../html/login.html';</script>";
    } else {
        // Preparar y ejecutar consulta
        $sql = "SELECT id, rol FROM usuarios WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $user, $pass);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($id, $rol);

        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user;
            $_SESSION['rol'] = $rol;

            // Redirigir a ../html/inicio.html
            header("Location: ../html/inicio.html");
        } else {
            echo "<script>alert('Nombre de usuario o contraseña incorrectos.'); window.location.href='../html/login.html';</script>";
        }

        $stmt->close();
    }
}

$conn->close();
?>
